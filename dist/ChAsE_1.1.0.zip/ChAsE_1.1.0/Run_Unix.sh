#!/bin/sh
cd "$(dirname "$0")"
java -Xmx4G -jar chase.jar
read -n 1 -s