#!/bin/sh
cd "$(dirname "$0")"
java -Xms512m -Xmx2048m -jar chase.jar
read -n 1 -s